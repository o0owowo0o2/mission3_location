import React from 'react';
import 'bootstrap/dist/css/bootstrap.css'; 
import Router_jje from './components/Router_jje';

function App() {
  return (
    <div>
      <Router_jje />
        
      
    </div>
  );
}

export default App;