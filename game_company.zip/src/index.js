import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css'; // 기본 CSS 스타일
import App from './App'; // 앱의 메인 컴포넌트
import reportWebVitals from './reportWebVitals'; // 성능 측정 도구
import { BrowserRouter } from "react-router-dom"; // 라우터


// 아래는 React 프로젝트를 위한 index.js 파일의 예시입니다.
// index.js 파일은 React 애플리케이션의 진입점이며,
// 여기에서 앱의 최상위 컴포넌트를 DOM에 렌더링합니다.
// BrowserRouter를 사용하여 앱에 라우팅 기능을 추가했습니다.

// BrowserRouter를 사용함으로써, 앱 내에서 선언된 모든 라우트(Route)에 대해
// 클라이언트 사이드 라우팅을 활성화합니다. 이를 통해 페이지를 새로 고침하지 않고도 URL을 변경하며 컴포넌트를 전환할 수 있습니다.
// React.StrictMode는 개발 모드에서 React 애플리케이션의 잠재적인 문제를 발견하기 위해
// 추가적인 체크와 경고를 제공합니다. 프로덕션 빌드에는 영향을 주지 않으며, 필요에 따라 주석 처리를 해제하여 사용할 수 있습니다.
// reportWebVitals 함수는 애플리케이션의 성능을 측정하는 데 사용됩니다.
// 기본적으로 주석 처리되어 있으며, 성능 로깅이 필요한 경우 활성화할 수 있습니다.
// 이 구성은 React 애플리케이션의 기본 구조를 제공하며, 라우팅 기능을 포함하여 더 복잡한 싱글 페이지 애플리케이션(SPA)을 구축하는 데 사용됩니다.

const root = ReactDOM.createRoot(document.getElementById('root')); // root 엘리먼트에 접근
root.render(
  // React.StrictMode 주석 처리됨. 개발 모드에서의 추가적인 체크와 경고를 위해 사용할 수 있음
  <BrowserRouter>
    <App />
  </BrowserRouter>
  // React.StrictMode
);

// 성능 측정을 위해 reportWebVitals 함수 사용. 필요에 따라 console.log로 결과를 출력하거나
// 분석 엔드포인트로 보낼 수 있음. 자세한 정보는 https://bit.ly/CRA-vitals 참고
reportWebVitals();