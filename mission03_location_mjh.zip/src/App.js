import React from "react";
import { BrowserRouter as Router, Route, Link, Switch } from "react-router-dom";
import Home from "./common/Home";
import Landing_MJH from "./components_mjh/Landing_MJH";
import Location_MJH from "./components_mjh/Location_MJH";
import Location_csb from "./components_csb/Location_csb";
import Main_csb from "./components_csb/Main_csb";
import Location_jje from "./components_jje/Location_jje";
import Location_SJE from "./components_sje/Location_SJE";
import Location from "./components_mdy/Location";



function App() {
  return (
    <Router>
      <div>
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/mjh" component={Landing_MJH} />
          <Route path="/location_mjh" component={Location_MJH} />
          
          <Route path="/csb" component={Main_csb} />
          <Route path="/location_csb" component={Location_csb} />

          <Route path="/jje" component={Location_jje} />

          <Route path="/sje" component={Location_SJE} />

          <Route path="/mdy" component={Location} />


        </Switch>
      </div>
    </Router>
  );
}

export default App;
