import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div>
      <h1>Welcome to Mission03</h1>
      <ul>
        <li>
          <Link to="/jje">장정은</Link>
        </li>
        <li>
          <Link to="/sje">서정은</Link>
        </li>
        <li>
          <Link to="/mjh">민지홍</Link>
        </li>
        <li>
          <Link to="/mdy">문도연</Link>
        </li>
        <li>
          <Link to="/csb">최승빈</Link>
        </li>
      </ul>
    </div>
  );
};

export default Home;
