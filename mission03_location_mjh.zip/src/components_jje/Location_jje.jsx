// rsf
// 맨위에 global kakao를 선언해서,
// kakao를 글로벌로 선언해서 사용합니다.
/* global kakao */
import React, {useEffect} from 'react';
import { Link } from 'react-router-dom';
import '../css_jje/location_jje.css';
import Container from 'react-bootstrap/Container';

const location_name = "라이엇게임즈코리아";
const kakaoMapScript = () => {

    var mapContainer = document.getElementById('map'), // 지도를 표시할 div 
    mapOption = { 
        center: new kakao.maps.LatLng(37.57141, 126.9822), // 지도의 중심좌표
        level: 3 // 지도의 확대 레벨
    };

var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다

// 마커가 표시될 위치입니다 
var markerPosition  = new kakao.maps.LatLng(37.57141, 126.9822); 

// 마커를 생성합니다
var marker = new kakao.maps.Marker({
    position: markerPosition
});

// 마커가 지도 위에 표시되도록 설정합니다
marker.setMap(map);

// 아래 코드는 지도 위의 마커를 제거하는 코드입니다
// marker.setMap(null);    

// window 객체 활용 map 안에 마커 중앙 표시 : resize 처리(추가 코딩)
window.addEventListener('resize', function(){
    map.setCenter(new kakao.maps.LatLng(37.57141, 126.9822))
});

};

function Location_jje(){
    useEffect(()=>{
        kakaoMapScript();
    }, []);
    return(
        <>
          <Container>
           <div className='jje_map'>
                <h1>{location_name} 찾아오시는 길</h1> <br />
                <div id="map" style={{width:'100%', height:'350px'}}></div>
            </div>
            <p> 서울특별시 강남구 삼성동 테헤란로 521 파르나스타워 30층 </p>
            <br /><br /><br /><br /><br /><br /><br /><br />
          </Container>
         
        </>
    );
}

export default Location_jje;