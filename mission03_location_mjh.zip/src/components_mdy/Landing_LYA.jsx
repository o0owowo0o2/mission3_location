import React from "react";
import { Link } from "react-router-dom";

const Landing_LYA = () => {
  return (
    <div>
      <h1>이영애의 페이지</h1>
      <Link to="/">메인으로</Link> |<Link to="/company-lya">회사 소개</Link>
    </div>
  );
};

export default Landing_LYA;
