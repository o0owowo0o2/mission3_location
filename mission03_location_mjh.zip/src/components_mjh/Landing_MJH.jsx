import React from "react";
import { Link } from "react-router-dom";
import '../css_mjh/landing_mjh.css';


const Landing_MJH = () => {
  return (
    <div className="landing-wrapper">
    <div className="text-wrapper">
      <h1 className='animate__animated animate__fadeIn'></h1>
      <a href="/">처음으로</a> |  <a href="/location_mjh">회사 위치</a>
    </div>
    </div>
  );
};

export default Landing_MJH;
