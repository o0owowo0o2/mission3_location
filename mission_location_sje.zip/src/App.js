import React from 'react';
import 'bootstrap/dist/css/bootstrap.css'; 

import { BrowserRouter as Router, Route } from 'react-router-dom';
import Location_SJE from './components_sje/Location_SJE';

function App() {
  return (
    <div>
      <Router>
        <Route path="/location_sje" component={Location_SJE}/>
      </Router>
    </div>
  );
}

export default App;