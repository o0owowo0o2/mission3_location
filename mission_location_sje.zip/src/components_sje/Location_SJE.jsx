/* global kakao */

import React, { useEffect } from 'react';
import Container from 'react-bootstrap/Container'
import { Link } from 'react-router-dom';
import '../css_sje/location_sje.css';

const kakaoMapScript = () => {  

    var mapContainer = document.getElementById('map'), // 지도를 표시할 div 
    mapOption = { 
        center: new kakao.maps.LatLng(37.33935, 127.1092), // 지도의 중심좌표
        level: 3 // 지도의 확대 레벨
    };

    var map = new kakao.maps.Map(mapContainer, mapOption);

    // 마커가 표시될 위치입니다 
    var markerPosition  = new kakao.maps.LatLng(37.33935, 127.1092); 

    // 마커를 생성합니다
    var marker = new kakao.maps.Marker({
        position: markerPosition
    });

    // 마커가 지도 위에 표시되도록 설정합니다
    marker.setMap(map);

    var iwContent = '<div style="padding:5px;">Colons:D <br><a href="https://map.kakao.com/link/map/Colons:D,37.33935, 127.1092" style="color:#48b0ed; padding:5px;" target="_blank">큰지도보기</a> <a href="https://map.kakao.com/link/to/Colons:D,37.33935, 127.1092" style="color:#48b0ed;padding:5px;" target="_blank">길찾기</a></div>', // 인포윈도우에 표출될 내용으로 HTML 문자열이나 document element가 가능합니다
        iwPosition = new kakao.maps.LatLng(37.33935, 127.1092); //인포윈도우 표시 위치입니다

    // 인포윈도우를 생성합니다
    var infowindow = new kakao.maps.InfoWindow({
        position : iwPosition, 
        content : iwContent 
    });
    
    // window 객체 활용 map 안에 마커 중앙 표시 : resize 처리(추가 코딩)
    window.addEventListener('resize', function(){
        map.setCenter(new kakao.maps.LatLng(37.33935, 127.1092))
    })    
    // 마커 위에 인포윈도우를 표시합니다. 두번째 파라미터인 marker를 넣어주지 않으면 지도 위에 표시됩니다
    infowindow.open(map, marker); 


}

function Location_SJE() {

    useEffect(() => {
        kakaoMapScript();
    }, []);
    
    return (
        <div id='location-wrapper-sje'>
            <div className='header'>
            <Container>
                <Link to='/sje'>
                    <img className='logo' src="images_sje/logo_sje.svg" alt="logo" />
                </Link>
            </Container>
            </div>
            <Container>
                <div className='header-sje'>
                    <h1>Location</h1>
                    <p>찾아오시는길</p>
                    <hr />
                    <div className='location-map'>
                        <div id="map" style={{width:'100', height:'300px'}}></div>
                    </div>
                </div>
                <div className='location-content'>
                <h5 className='h5'>대중교통</h5>
                    <div className='location-content-1'>
                        <img src="images_sje/subway.svg" alt="지하철" />
                        <h5>지하철</h5>
                        <p>수인분당선 오리역</p>
                    </div>
                    <div className='location-content-2'>
                        <img src="images_sje/bus.svg" alt="버스" />
                        <h5>버스</h5>
                        <p>100, 250, 300, 88, 3-4, 3-5</p>
                    </div>
                </div>
                <div className='location-minimap'>
                    <h5 className='h5'>약도</h5>
                    <img src="images_sje/map.svg" alt="약도" />
                    <p>경기도 성남시 분당구 성남대로 지하55 (구미동 197-1) <br />수인분당선 오리역 2번 출구 도보 4분</p>
                </div>
                <div className='space'></div>
            </Container>
        </div>
    );
}

export default Location_SJE;