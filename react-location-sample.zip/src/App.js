// rsf
import React from 'react';
import {BrowserRouter as Router, Route} from 'react-router-dom';
import Landing from './components/Landing';
import Main from './components/Main';
import Location from './components/Location';
import About from './components/About';
import Introduction from './components/Introduction';
import Qna from './components/Qna';
// 중요 : 아래의 bootstrap.css를 반드시! import 해야 합니다!
import 'bootstrap/dist/css/bootstrap.css'; 

function App() {
  return (
    <div>
      <Router>
        <Route path="/" component={Landing} exact={true} />
        <Route path="/main" component={Main} />
        <Route path="/about" component={About} />
        <Route path="/introduction" component={Introduction} />
        <Route path="/qna" component={Qna} />
        <Route path="/location" component={Location} />
      </Router>
    </div>
  );
}

export default App;