// rsf
import React from 'react';
import { Link } from 'react-router-dom';

function Introduction() {
    return (
        <div>
            <p>
                <Link to="/main">메인 페이지로 Go!</Link>
            </p>
        </div>
    );
}

export default Introduction;