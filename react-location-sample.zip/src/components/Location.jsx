// rsf
// 맨위에 global kakao를 선언해서,
// kakao를 글로벌로 선언해서 사용합니다.
/* global kakao */
import React, {useEffect} from 'react';
import { Link } from 'react-router-dom';
import '../css/location.css';
import Container from 'react-bootstrap/Container';

// const location_name = "롯데월드 민속박물관";
const kakaoMapScript = () => {

    var mapContainer = document.getElementById('map'), // 지도를 표시할 div 
    mapOption = { 
        center: new kakao.maps.LatLng(37.51145, 127.0980), // 지도의 중심좌표
        level: 3 // 지도의 확대 레벨
    };

var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다

// 마커가 표시될 위치입니다 
var markerPosition  = new kakao.maps.LatLng(37.51145, 127.0980); 

// 마커를 생성합니다
var marker = new kakao.maps.Marker({
    position: markerPosition
});

// 마커가 지도 위에 표시되도록 설정합니다
marker.setMap(map);

// 아래 코드는 지도 위의 마커를 제거하는 코드입니다
// marker.setMap(null);    

// window 객체 활용 map 안에 마커 중앙 표시 : resize 처리(추가 코딩)
window.addEventListener('resize', function(){
    map.setCenter(new kakao.maps.LatLng(37.51145, 127.0980))
});

};

function Location(){
    useEffect(()=>{
        kakaoMapScript();
    }, []);
    return(
        <>
          <Container>
           <div className='wrapper'>
                <h2 className='mapTit'> 오시는 길</h2>
                <div id="map" style={{width:'100%', height:'425px'}}></div>
                <p>
                    <Link to="/main">메인 페이지로 Go!</Link>
                </p> 
            </div>
          </Container>
          <Container>
            <hr />
            <div className='wrapper'>
                
                <img className='company_image' src='images/190628_map_cut.jpg' alt='약도 이미지' />
            </div>            
          </Container>
          <Container>
            <hr />
            <div className='wrapper'>
                <p className='after'></p>
                <img src='images/icon.png' className='lctIcon'></img>
                <h2 className='traffic'>롯데월드 민속박물관 (서울 송파구 올림픽로 240)</h2>
                <div className='clearDiv'>
                    <div className='leftDiv'>
                        {/* <p class="tit">지하철 이용시</p> */}
                        <ul>
                            <li>
                             <p class="label"><span>2</span>2호선</p>
                             <span>2</span>
                             <p>잠실역 4번 출구</p>
                            </li>
                            <li>
                             <p class="label"><span>8</span>8호선</p>
                             <span>8</span>
                             <p>잠실역 4번 출구</p>
                            </li>
                        </ul>
                    </div>
                    <div className='rightDiv'>
                        {/* <p class="tit">버스 이용시 </p> */}
                            <ul>
                                <li>
                                    <p class="label">지선</p>
                                    <p>3217번, 3313번, 3314번, 3315번, 3317번, 3411번, 3414번, 4319번</p>
                                </li>
                                <li>
                                    <p class="label">광역</p>
                                    <p>1007-1번, 1100번, 1700번, 2000번, 6900번, 7007번, 8001번</p>
                                </li>
                                <li>
                                    <p class="label">간선</p>
                                    <p>301번, 341번, 360번, 362번</p>
                                </li>
                                <li>
                                    <p class="label">공항</p>
                                    <p>6000번, 6006번, 6705번, 6706A번</p>
                                </li>

                            </ul>
                        
                    </div>
                </div>
                {/* clearDiv */}
                <div className='afterD'>
                </div>

                <div className='guideBox'>

                </div>


            </div>
            {/* wrapper */}
          </Container>
          <div id='space'></div>
          <div id="footer">
        <div className="container">
          <div className="top">
            <div className="links">
              <a href="#">롯데월드 소개</a>
              <a href="#">기업제휴 및 입점문의</a>
              <a href="#">이용약관</a>
              <a href="#" className="cRed">개인정보처리방침</a>
              <a href="#">사이트맵</a>
            </div>
          </div>
          <div className="bottom">
            <div className="left">
              <div>
                <p>서울특별시 송파구 올림픽로 240 호텔롯데 롯데월드 | 대표자 : 최홍훈</p>
                <p>사업자등록번호 : 219-85-00014 통신판매업신고번호 : 송파 제5513호 전화 : 1661-2000</p>
              </div>
              <p className="copyright">COPYRIGHT 2018 LOTTEWORLD. ALL RIGHTS RESERVED.</p>
            </div>
            <div className="familySite">
              <select>
                <option value="">계열사 관련 사이트</option>
                <option value="">LOTTE Family</option>
                <option value="">롯데웰프드</option>
                <option value="">롯데칠성음료(음료BG)</option>
              </select>
            </div>
          </div>
        </div>
        <div className="topBtn">
          <button type="button">
            <img src="images/top_btn.png" alt="위로가기" />
          </button>
        </div>
      </div>
        </>
    );
}

export default Location;