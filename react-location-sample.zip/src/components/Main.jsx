// rsf
import React from 'react';
import { Link } from 'react-router-dom';

function Main() {
    return (
        <div>            
            <Link to="/about">회사소개 웹페이지로 Go!</Link>
            <br />
            <Link to="/introduction">상품소개 웹페이지로 Go!</Link>
            <br />
            <Link to="/qna">자주묻는질문 웹페이지로 Go!</Link>
            <br />
            <Link to="/location">찾아오시는길 페이지로 Go!</Link>
            <br />
            
        </div>
    );
}

export default Main;